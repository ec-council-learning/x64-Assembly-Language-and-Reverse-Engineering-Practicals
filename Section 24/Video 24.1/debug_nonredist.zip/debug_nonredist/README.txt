Dear Students,

It seems that the creator or the whoami crackme has built it as a debug built which 
relies on debug versions of the following DLLs:

msvcp140d.dll, vcruntime140d.dll, and ucrtbased.dll

So, if your whoami cannot run, you have two solutions:

1. Install Microsoft Visual Studio 2022 Community edition. During installation, 
make sure to select the C++ Development workload. This will ensure that the 
necessary debug runtime libraries are installed.

2. Download and unzip the file debug_nonredist.zip from the resource section, and
copy the two folders x64 and x86 to the same directory as whoami crackme, or, to
the system directoriesL C:\Windows\System32 (for 64-bit) or, C:\Windows\SysWOW64 (for 32-bit)


Paul