#include <stdio.h>

int main()
{
	int a;
	printf("enter an integer: ");
	scanf("%d", &a);
	printf("you entered: %d\n", a);
	printf("\n");
	system("pause");
	return 0;
}